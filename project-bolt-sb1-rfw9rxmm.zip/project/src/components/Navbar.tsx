import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Search, User, ShoppingCart, Menu, X, LogOut } from 'lucide-react';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <span className="text-xl font-bold text-blue-600">ElectroRate</span>
            </Link>
          </div>
          
          <div className="hidden md:flex md:items-center md:space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="bg-gray-100 pl-10 pr-4 py-2 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
              />
              <Search size={18} className="absolute left-3 top-2.5 text-gray-500" />
            </div>
          </div>
          
          <div className="hidden md:flex md:items-center md:space-x-4">
            <Link 
              to="/profile" 
              className="p-2 rounded-full hover:bg-gray-100 text-gray-700 transition-colors duration-200"
            >
              <User size={20} />
            </Link>
            <button className="p-2 rounded-full hover:bg-gray-100 text-gray-700 transition-colors duration-200">
              <ShoppingCart size={20} />
            </button>
            {user && (
              <button 
                onClick={handleLogout}
                className="flex items-center text-sm px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100 transition-colors duration-200"
              >
                <LogOut size={18} className="mr-1" />
                Logout
              </button>
            )}
          </div>
          
          <div className="flex md:hidden items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-md text-gray-700 hover:bg-gray-100"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1 px-4">
            <div className="relative mb-3">
              <input
                type="text"
                placeholder="Search products..."
                className="bg-gray-100 pl-10 pr-4 py-2 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full"
              />
              <Search size={18} className="absolute left-3 top-2.5 text-gray-500" />
            </div>
            
            <Link 
              to="/profile" 
              className="flex items-center text-base px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              <User size={18} className="mr-2" />
              Profile
            </Link>
            
            <button 
              className="flex items-center text-base w-full text-left px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              <ShoppingCart size={18} className="mr-2" />
              Cart
            </button>
            
            {user && (
              <button 
                onClick={() => {
                  handleLogout();
                  setIsMenuOpen(false);
                }}
                className="flex items-center text-base w-full text-left px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100"
              >
                <LogOut size={18} className="mr-2" />
                Logout
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;