import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import StarRating from './StarRating';
import { ShoppingCart, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onRatingChange: (productId: string, rating: number) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onRatingChange }) => {
  const handleRatingChange = (rating: number) => {
    onRatingChange(product.id, rating);
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-lg border border-gray-100">
      <div className="relative">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2">
          <button className="bg-white p-1.5 rounded-full shadow-sm hover:bg-gray-100 transition-colors duration-200">
            <Heart size={18} className="text-gray-500 hover:text-red-500 transition-colors duration-200" />
          </button>
        </div>
        <div className="absolute top-0 left-0 bg-blue-500 text-white text-xs font-semibold px-2 py-1 rounded-br-lg">
          {product.quality}
        </div>
      </div>

      <div className="p-4">
        <Link to={`/product/${product.id}`} className="group">
          <h3 className="font-semibold text-lg mb-1 group-hover:text-blue-600 transition-colors duration-200">{product.name}</h3>
        </Link>
        
        <div className="flex justify-between items-center mt-2 mb-3">
          <span className="text-xl font-bold text-blue-900">${product.price.toLocaleString()}</span>
          <div className="flex text-sm text-gray-500">
            {product.discount > 0 && (
              <span className="line-through mr-2">${(product.price / (1 - product.discount/100)).toFixed(2)}</span>
            )}
            {product.discount > 0 && (
              <span className="text-green-600 font-medium">-{product.discount}%</span>
            )}
          </div>
        </div>
        
        <div className="mb-3">
          <StarRating 
            initialRating={product.userRating || 0} 
            onRatingChange={handleRatingChange} 
            size={20}
          />
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-500">{product.brand}</span>
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-md transition-colors duration-200 flex items-center text-sm">
            <ShoppingCart size={16} className="mr-1" />
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;