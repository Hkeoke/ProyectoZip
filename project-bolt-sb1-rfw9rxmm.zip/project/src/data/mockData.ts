import { Product } from '../types';

export const mockProducts: Product[] = [
  {
    id: "1",
    name: "Smart 4K TV 55-inch",
    brand: "TechVision",
    category: "Televisions",
    description: "Experience stunning 4K resolution with this 55-inch Smart TV featuring HDR technology, voice control, and seamless streaming capabilities. Enjoy vibrant colors and deep blacks with the latest display technology.",
    price: 799.99,
    discount: 10,
    quality: "Premium",
    image: "https://images.pexels.com/photos/6782351/pexels-photo-6782351.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "2",
    name: "High-Performance Blender",
    brand: "KitchenPro",
    category: "Kitchen Appliances",
    description: "This powerful 1200W blender features six stainless steel blades that can blend even the toughest ingredients. Perfect for smoothies, soups, and frozen desserts with variable speed control.",
    price: 129.99,
    discount: 0,
    quality: "Premium",
    image: "https://images.pexels.com/photos/3656498/pexels-photo-3656498.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "3",
    name: "Smart Refrigerator with Ice Maker",
    brand: "CoolTech",
    category: "Refrigerators",
    description: "This energy-efficient smart refrigerator features a built-in ice maker, temperature control via smartphone app, and spacious compartments to keep your food fresh longer.",
    price: 1499.99,
    discount: 5,
    quality: "Deluxe",
    image: "https://images.pexels.com/photos/5824883/pexels-photo-5824883.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "4",
    name: "Automatic Espresso Machine",
    brand: "BrewMaster",
    category: "Coffee Makers",
    description: "Create barista-quality espresso at home with this fully automatic espresso machine. Features include built-in grinder, milk frother, and programmable settings for your perfect cup.",
    price: 599.99,
    discount: 0,
    quality: "Deluxe",
    image: "https://images.pexels.com/photos/3570945/pexels-photo-3570945.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "5",
    name: "Robot Vacuum Cleaner",
    brand: "CleanBot",
    category: "Cleaning Appliances",
    description: "This intelligent robot vacuum navigates your home, automatically adjusting to different floor types. Schedule cleaning sessions through the app and enjoy hands-free floor maintenance.",
    price: 349.99,
    discount: 15,
    quality: "Premium",
    image: "https://images.pexels.com/photos/844874/pexels-photo-844874.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "6",
    name: "Digital Air Fryer",
    brand: "CrispTech",
    category: "Kitchen Appliances",
    description: "Cook healthier meals with up to 75% less fat using this digital air fryer. The touch display offers preset cooking programs and the large capacity is perfect for family meals.",
    price: 149.99,
    discount: 0,
    quality: "Standard",
    image: "https://images.pexels.com/photos/6605308/pexels-photo-6605308.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "7",
    name: "Front-Loading Washing Machine",
    brand: "CleanCycle",
    category: "Laundry Appliances",
    description: "This energy-efficient front-loading washing machine features multiple wash cycles, steam cleaning, and WiFi connectivity to control and monitor your laundry from your smartphone.",
    price: 749.99,
    discount: 5,
    quality: "Premium",
    image: "https://images.pexels.com/photos/5816303/pexels-photo-5816303.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "8",
    name: "Smart Wi-Fi Speaker",
    brand: "SoundMax",
    category: "Audio Equipment",
    description: "Fill your home with rich, room-filling sound with this smart WiFi speaker. Compatible with voice assistants and featuring multi-room connectivity for a seamless audio experience.",
    price: 199.99,
    discount: 0,
    quality: "Premium",
    image: "https://images.pexels.com/photos/10912149/pexels-photo-10912149.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "9",
    name: "Programmable Slow Cooker",
    brand: "SimmerPro",
    category: "Kitchen Appliances",
    description: "Set it and forget it with this programmable slow cooker featuring digital controls, multiple cooking modes, and a removable ceramic pot for easy serving and cleaning.",
    price: 89.99,
    discount: 10,
    quality: "Standard",
    image: "https://images.pexels.com/photos/6824458/pexels-photo-6824458.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "10",
    name: "Ultra Quiet Dishwasher",
    brand: "SilentWash",
    category: "Kitchen Appliances",
    description: "This ultra-quiet dishwasher operates at just 42 dB and features adjustable racks, multiple wash cycles, and a sanitize option to eliminate 99.9% of bacteria.",
    price: 649.99,
    discount: 0,
    quality: "Deluxe",
    image: "https://images.pexels.com/photos/4995448/pexels-photo-4995448.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "11",
    name: "Electric Toothbrush",
    brand: "DentalPro",
    category: "Personal Care",
    description: "Achieve a professional clean with this electric toothbrush featuring sonic technology, five cleaning modes, and a pressure sensor to protect gums from excessive brushing force.",
    price: 79.99,
    discount: 20,
    quality: "Premium",
    image: "https://images.pexels.com/photos/3662669/pexels-photo-3662669.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: "12",
    name: "Steam Iron",
    brand: "PressWell",
    category: "Laundry Appliances",
    description: "This powerful steam iron features a non-stick soleplate, adjustable steam settings, and a self-cleaning function to keep your clothes looking crisp and professional.",
    price: 59.99,
    discount: 0,
    quality: "Standard",
    image: "https://images.pexels.com/photos/228831/pexels-photo-228831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  }
];