import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';
import { mockProducts } from '../data/mockData';
import { Filter, SlidersHorizontal } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  
  const categories = Array.from(new Set(mockProducts.map(p => p.category)));
  
  useEffect(() => {
    // Simulate loading data from an API
    const loadProducts = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Get user ratings from localStorage if they exist
      const storedRatings = localStorage.getItem('userRatings');
      let userRatings: Record<string, number> = {};
      
      if (storedRatings) {
        try {
          userRatings = JSON.parse(storedRatings);
        } catch (e) {
          console.error('Failed to parse stored ratings');
        }
      }
      
      // Apply any stored user ratings to products
      const productsWithRatings = mockProducts.map(product => ({
        ...product,
        userRating: userRatings[product.id] || 0
      }));
      
      setProducts(productsWithRatings);
      setLoading(false);
    };
    
    loadProducts();
  }, []);
  
  const handleRatingChange = (productId: string, rating: number) => {
    // Update product rating in state
    setProducts(prevProducts => 
      prevProducts.map(product => 
        product.id === productId 
          ? { ...product, userRating: rating } 
          : product
      )
    );
    
    // Save rating to localStorage
    const storedRatings = localStorage.getItem('userRatings');
    let userRatings: Record<string, number> = {};
    
    if (storedRatings) {
      try {
        userRatings = JSON.parse(storedRatings);
      } catch (e) {
        console.error('Failed to parse stored ratings');
      }
    }
    
    userRatings[productId] = rating;
    localStorage.setItem('userRatings', JSON.stringify(userRatings));
  };
  
  // Filter products based on search and category
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                        product.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory ? product.category === selectedCategory : true;
    
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Electronics Products</h1>
            <p className="text-gray-600 mt-1">Rate and discover quality appliances</p>
          </div>
          
          <div className="mt-4 md:mt-0 w-full md:w-auto">
            <div className="flex items-center">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white border border-gray-300 rounded-md px-4 py-2 w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="ml-2 p-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors duration-200"
              >
                <SlidersHorizontal size={20} />
              </button>
            </div>
          </div>
        </div>
        
        {showFilters && (
          <div className="bg-white p-4 rounded-lg shadow-sm mb-6 border border-gray-100 animate-fadeIn">
            <div className="flex items-center mb-3">
              <Filter size={18} className="text-gray-500 mr-2" />
              <h2 className="text-lg font-medium">Filters</h2>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`px-3 py-1.5 rounded-full text-sm ${
                  selectedCategory === null
                    ? 'bg-blue-100 text-blue-800 font-medium'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } transition-colors duration-200`}
              >
                All Categories
              </button>
              
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-3 py-1.5 rounded-full text-sm ${
                    selectedCategory === category
                      ? 'bg-blue-100 text-blue-800 font-medium'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  } transition-colors duration-200`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {loading ? (
          <div className="py-20 flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20">
                <h3 className="text-lg font-medium text-gray-900">No products found</h3>
                <p className="mt-1 text-gray-500">Try changing your search or filters</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onRatingChange={handleRatingChange}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default Dashboard;