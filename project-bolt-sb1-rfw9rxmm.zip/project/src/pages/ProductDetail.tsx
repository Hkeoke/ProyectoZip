import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import StarRating from '../components/StarRating';
import { Product } from '../types';
import { mockProducts } from '../data/mockData';
import { 
  ShoppingCart, 
  Heart, 
  TruckIcon, 
  ShieldCheck, 
  ArrowLeft, 
  Share2
} from 'lucide-react';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  
  useEffect(() => {
    const loadProduct = async () => {
      setLoading(true);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Find product
      const foundProduct = mockProducts.find(p => p.id === id);
      
      // Get user rating if it exists
      const storedRatings = localStorage.getItem('userRatings');
      let userRating = 0;
      
      if (storedRatings && foundProduct) {
        try {
          const ratings = JSON.parse(storedRatings);
          userRating = ratings[foundProduct.id] || 0;
        } catch (e) {
          console.error('Failed to parse stored ratings');
        }
      }
      
      if (foundProduct) {
        setProduct({
          ...foundProduct,
          userRating
        });
      }
      
      setLoading(false);
    };
    
    if (id) {
      loadProduct();
    }
  }, [id]);
  
  const handleRatingChange = (rating: number) => {
    if (!product) return;
    
    // Update product in state
    setProduct(prev => prev ? { ...prev, userRating: rating } : null);
    
    // Save rating to localStorage
    const storedRatings = localStorage.getItem('userRatings');
    let userRatings: Record<string, number> = {};
    
    if (storedRatings) {
      try {
        userRatings = JSON.parse(storedRatings);
      } catch (e) {
        console.error('Failed to parse stored ratings');
      }
    }
    
    userRatings[product.id] = rating;
    localStorage.setItem('userRatings', JSON.stringify(userRatings));
  };
  
  const handleQuantityChange = (value: number) => {
    if (value >= 1 && value <= 10) {
      setQuantity(value);
    }
  };
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-2xl font-bold">Product not found</h2>
          <p className="mt-2 text-gray-600">The product you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate('/')}
            className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-800"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back to products
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <button
          onClick={() => navigate('/')}
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4"
        >
          <ArrowLeft size={16} className="mr-1" />
          Back to products
        </button>
        
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
            <div className="flex flex-col">
              <div className="relative bg-gray-100 rounded-lg overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-auto object-contain aspect-square"
                />
                <div className="absolute top-0 left-0 bg-blue-500 text-white text-sm font-semibold px-2 py-1 rounded-br-lg">
                  {product.quality}
                </div>
                
                {product.discount > 0 && (
                  <div className="absolute top-0 right-0 bg-green-500 text-white text-sm font-semibold px-2 py-1 rounded-bl-lg">
                    {product.discount}% OFF
                  </div>
                )}
              </div>
              
              <div className="flex justify-between mt-4">
                <div className="flex-1 flex justify-center items-center border border-gray-200 rounded-md py-2 mx-1 cursor-pointer hover:bg-gray-50">
                  <Heart size={20} className="text-gray-500" />
                </div>
                <div className="flex-1 flex justify-center items-center border border-gray-200 rounded-md py-2 mx-1 cursor-pointer hover:bg-gray-50">
                  <Share2 size={20} className="text-gray-500" />
                </div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{product.name}</h1>
                  <p className="text-sm text-gray-500 mt-1">Brand: {product.brand}</p>
                </div>
              </div>
              
              <div className="flex items-center mt-4">
                <StarRating
                  initialRating={product.userRating || 0}
                  onRatingChange={handleRatingChange}
                  size={24}
                />
                <span className="ml-2 text-sm text-gray-500">
                  Your rating
                </span>
              </div>
              
              <div className="mt-6">
                <div className="flex items-end">
                  <span className="text-3xl font-bold text-blue-900">${product.price.toLocaleString()}</span>
                  {product.discount > 0 && (
                    <span className="ml-2 text-lg text-gray-500 line-through">
                      ${(product.price / (1 - product.discount/100)).toFixed(2)}
                    </span>
                  )}
                  {product.discount > 0 && (
                    <span className="ml-2 text-sm bg-green-100 text-green-800 px-2 py-0.5 rounded">
                      Save {product.discount}%
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Availability: <span className="text-green-600 font-medium">In Stock</span>
                </p>
              </div>
              
              <div className="mt-6 border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium">About this item</h3>
                <p className="mt-2 text-gray-600">{product.description}</p>
                
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <TruckIcon size={18} className="text-gray-500 mr-2" />
                    <span className="text-sm text-gray-600">Free delivery</span>
                  </div>
                  <div className="flex items-center">
                    <ShieldCheck size={18} className="text-gray-500 mr-2" />
                    <span className="text-sm text-gray-600">2 year warranty</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 border-t border-gray-200 pt-6">
                <div className="flex items-center mb-4">
                  <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mr-4">
                    Quantity
                  </label>
                  <div className="flex items-center border border-gray-300 rounded-md">
                    <button
                      type="button"
                      onClick={() => handleQuantityChange(quantity - 1)}
                      className="px-3 py-1 text-gray-600 hover:bg-gray-100 focus:outline-none"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      id="quantity"
                      value={quantity}
                      onChange={(e) => handleQuantityChange(parseInt(e.target.value))}
                      min="1"
                      max="10"
                      className="w-12 text-center border-0 focus:outline-none focus:ring-0"
                    />
                    <button
                      type="button"
                      onClick={() => handleQuantityChange(quantity + 1)}
                      className="px-3 py-1 text-gray-600 hover:bg-gray-100 focus:outline-none"
                    >
                      +
                    </button>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md flex-1 flex items-center justify-center transition-colors duration-200">
                    <ShoppingCart size={20} className="mr-2" />
                    Add to Cart
                  </button>
                  <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-md flex-1 transition-colors duration-200">
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProductDetail;