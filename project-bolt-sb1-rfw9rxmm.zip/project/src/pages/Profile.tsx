import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import StarRating from '../components/StarRating';
import { Product } from '../types';
import { mockProducts } from '../data/mockData';
import { useAuth } from '../contexts/AuthContext';
import { User, Star, Settings, LogOut } from 'lucide-react';

const Profile: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [ratedProducts, setRatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('ratings');
  
  useEffect(() => {
    // Load user's rated products
    const loadRatedProducts = async () => {
      setLoading(true);
      
      // Get user ratings from localStorage
      const storedRatings = localStorage.getItem('userRatings');
      let userRatings: Record<string, number> = {};
      
      if (storedRatings) {
        try {
          userRatings = JSON.parse(storedRatings);
        } catch (e) {
          console.error('Failed to parse stored ratings');
        }
      }
      
      // Filter products that the user has rated
      const rated = mockProducts.filter(product => userRatings[product.id] && userRatings[product.id] > 0)
        .map(product => ({
          ...product,
          userRating: userRatings[product.id]
        }));
      
      setRatedProducts(rated);
      setLoading(false);
    };
    
    loadRatedProducts();
  }, []);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const handleRemoveRating = (productId: string) => {
    // Remove rating from list
    setRatedProducts(prev => prev.filter(p => p.id !== productId));
    
    // Remove from localStorage
    const storedRatings = localStorage.getItem('userRatings');
    
    if (storedRatings) {
      try {
        const userRatings = JSON.parse(storedRatings);
        delete userRatings[productId];
        localStorage.setItem('userRatings', JSON.stringify(userRatings));
      } catch (e) {
        console.error('Failed to parse stored ratings');
      }
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 h-32"></div>
          
          <div className="px-6 sm:px-8">
            <div className="flex flex-col sm:flex-row items-center sm:items-end -mt-16 sm:-mt-12 mb-6 sm:mb-8">
              <div className="bg-white p-2 rounded-full shadow-md mb-4 sm:mb-0">
                <div className="bg-blue-100 rounded-full p-4">
                  <User size={40} className="text-blue-600" />
                </div>
              </div>
              
              <div className="sm:ml-6 text-center sm:text-left">
                <h1 className="text-2xl font-bold text-gray-900">{user?.username || 'User'}</h1>
                <p className="text-gray-600">{user?.email || 'user@example.com'}</p>
              </div>
              
              <div className="sm:ml-auto mt-4 sm:mt-0 flex space-x-2">
                <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
                  <Settings size={16} className="mr-1" />
                  Settings
                </button>
                <button 
                  onClick={handleLogout}
                  className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                >
                  <LogOut size={16} className="mr-1" />
                  Logout
                </button>
              </div>
            </div>
            
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex space-x-8">
                <button
                  onClick={() => setActiveTab('ratings')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'ratings'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } transition-colors duration-200`}
                >
                  <div className="flex items-center">
                    <Star size={16} className="mr-2" />
                    My Ratings
                  </div>
                </button>
                
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'orders'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } transition-colors duration-200`}
                >
                  <div className="flex items-center">
                    <ShoppingCart size={16} className="mr-2" />
                    My Orders
                  </div>
                </button>
              </nav>
            </div>
            
            <div className="py-6">
              {activeTab === 'ratings' && (
                <div>
                  <h2 className="text-lg font-medium mb-4">Products You've Rated</h2>
                  
                  {loading ? (
                    <div className="py-10 flex justify-center">
                      <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
                    </div>
                  ) : (
                    <>
                      {ratedProducts.length === 0 ? (
                        <div className="text-center py-10 bg-gray-50 rounded-lg">
                          <Star size={48} className="mx-auto text-gray-300 mb-2" />
                          <h3 className="text-lg font-medium text-gray-900">No rated products yet</h3>
                          <p className="mt-1 text-gray-500">Start rating products to see them here</p>
                          <button
                            onClick={() => navigate('/')}
                            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none"
                          >
                            Browse Products
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {ratedProducts.map(product => (
                            <div key={product.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden flex flex-col sm:flex-row">
                              <div className="w-full sm:w-32 h-32 flex-shrink-0">
                                <img 
                                  src={product.image} 
                                  alt={product.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              
                              <div className="p-4 flex-1 flex flex-col justify-between">
                                <div>
                                  <div className="flex justify-between">
                                    <h3 className="font-medium text-gray-900">{product.name}</h3>
                                    <span className="text-sm text-gray-500">{new Date().toLocaleDateString()}</span>
                                  </div>
                                  <p className="text-sm text-gray-500 mt-1">{product.brand}</p>
                                  <div className="mt-2">
                                    <StarRating
                                      initialRating={product.userRating || 0}
                                      readOnly={true}
                                      size={20}
                                    />
                                  </div>
                                </div>
                                
                                <div className="mt-4 flex justify-between items-center">
                                  <button
                                    onClick={() => navigate(`/product/${product.id}`)}
                                    className="text-sm text-blue-600 hover:text-blue-800"
                                  >
                                    View Product
                                  </button>
                                  
                                  <button
                                    onClick={() => handleRemoveRating(product.id)}
                                    className="text-sm text-gray-500 hover:text-red-600"
                                  >
                                    Remove Rating
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
              
              {activeTab === 'orders' && (
                <div className="text-center py-10 bg-gray-50 rounded-lg">
                  <ShoppingCart size={48} className="mx-auto text-gray-300 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">No orders yet</h3>
                  <p className="mt-1 text-gray-500">Your purchase history will appear here</p>
                  <button
                    onClick={() => navigate('/')}
                    className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none"
                  >
                    Browse Products
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Profile;