export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  description: string;
  price: number;
  discount: number;
  quality: 'Standard' | 'Premium' | 'Deluxe';
  image: string;
  userRating?: number;
}